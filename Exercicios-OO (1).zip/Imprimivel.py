class imprimir():
  def imprimir(self):
    pass

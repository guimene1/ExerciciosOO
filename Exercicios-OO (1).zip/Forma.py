class Forma():
  def calcular_area(self):
    pass

class triangulo(Forma):
  def __init__(self, lado, altura):
    super().__init__()
    self.lado = lado
    self.altura = altura
    
  def calcular_area(self):
    area = (self.lado*self.altura)/2
    return area

class circulo(Forma):
  def __init__(self, raio):
    super().__init__()
    self.raio = raio

  def calcular_area(self):
    area = 3.14*(self.raio**2)
    return area  

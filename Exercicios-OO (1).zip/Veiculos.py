class Veiculos:
  def __init__(self, tipo, velocidade):
      self._tipo = tipo
      self._velocidade = velocidade

  def acelerar(self):
    self._velocidade += 5
    print(f"{self._tipo} acelerou e agora está a {self._velocidade} km/h")
  def descricao(self):
    print(f"{self._tipo} tem velocidade de {self._velocidade} km")
from Veiculos import Veiculos
from Imprimivel import imprimir

class Carro(Veiculos, imprimir):
  def __init__(self, tipo, velocidade, modelo, ano):
    super().__init__(tipo,velocidade)
    self._modelo = modelo
    self._ano = ano

  @property
  def modelo(self):
    return self._modelo

  @modelo.setter
  def modelo(self, modelo):
    self._modelo = modelo

  @property
  def ano(self):
    return self._ano

  @ano.setter
  def ano(self,ano):
    self._ano = ano

  def definir(self):
    print(f'O carro modelo {self._modelo} esta disponivel desde o ano {self._ano}.')

  def defpriv(self):
    print(f'O carro modelo {self._modelo} esta disponivel desde o ano {self._ano}.')

  def descricao(self):
    print(f'O carro do modelo {self.modelo} ano {self._ano}, tem velocidade de {self._velocidade} km')

  def imprimir(self):
    print(f'O carro do modelo {self.modelo} ano {self._ano}, tem velocidade de {self._velocidade}km e é muito bonito.')
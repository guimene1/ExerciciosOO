from Carro import Carro
from Forma import Forma
from Forma import circulo
from Forma import triangulo
from Moto import Moto
from Jogo import Mago
from Jogo import Guerreiro
from Jogo import Arqueiro



c1 = Carro("Carro",15,"C","C")
c1.modelo = "escort"
c1.ano = "1994"
c1.definir()
print("\n")
m1 = Moto( "Moto", 100,"Novo","Azul")

print("\nExercicio 4 ==========")
m1.descricao()
c1.descricao()

print("\nExercicio 5 ==========")
m1.acelerar()
m1.acelerar()


print("\nExercicio 6 ==========")
Veiculo = [Carro("Carro",23,"gol","2000"), Moto("Moto",80,"chopper","1990"),Carro("Carro",70,"fusca","1988"),Moto("Moto",60,"triumph","2018")]

for veiculo in Veiculo:
  print(veiculo.descricao())

print("\nExercicio 7 ==========")
tri1 = triangulo(lado=10, altura=5)
cir1 = circulo(raio = 2)

print(f'Area do circulo: {cir1.calcular_area()}')
print(f'Area do triangulo: {tri1.calcular_area()}') 

print("\nExercicio 8 ==========")
c1.imprimir()
m1.imprimir()

print("\nExercicio 10 ==========")
print("\n ==== Acoes do Jogo ====")
knight = Guerreiro("Gimli","Guerreiro",80, "Machado")
archer = Arqueiro("Legolas","Arqueiro",100,"Arco")
mago = Mago("Gandalf","Mago cinzento",90,"Cajado")

knight.descricao()
mago.descricao()
archer.descricao()
print("\n")

knight.acao()
mago.acao()
archer.acao()
print("\n")
mago.setarma = "Cajado e Espada"

knight.dano()
mago.cura()

mago.atacar()
archer.anao()

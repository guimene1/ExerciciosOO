class Jogo():
  def __init__(self,nome,classe,vida,arma):
    self.nome = nome
    self.classe = classe
    self.vida = vida
    self.arma = arma
  
  @property
  def getvida(self):
    return self.vida

  @getvida.setter
  def setvida(self,novavida):
      self.vida = novavida

  @property
  def getarma(self):
    return self.arma
    
  @getarma.setter
  def setarma(self,novaarma):
      self.arma = novaarma
  
  def atacar(self):
    print(f'O {self.classe} atacou com {self.arma}.')

  def status(self):
    print(f'O {self.classe} esta com {self.vida} pontos de vida.')

  def acao(self):
    pass

  def descricao(self):
    print(f'O {self.classe} {self.nome} esta carregando um {self.arma} e esta com {self.vida} pontos de vida.')

  def dano(self):
    self.vida -= 5
    print(f'O {self.classe} {self.nome} levou 5 de dano e agora está com {self.vida} pontos de vida.')

  def cura(self):
    self.vida += 5
    print(f'O {self.classe} {self.nome} curou 5 e agora está com {self.vida} pontos de vida.')
  
class Mago(Jogo):
  def __init__(self, nome, classe, vida, arma):
    super().__init__(nome, classe, vida, arma)

  def acao(self):
    print(f'O {self.classe} {self.nome} preparou suas magias.')
class Arqueiro(Jogo):
  def __init__(self, nome, classe, vida, arma):
    super().__init__(nome, classe, vida, arma)

  def acao(self):
    print(f'O {self.classe} {self.nome} ajeitou suas flechas.')

  def anao(self):
    print(f'{self.nome} tacou o anao Gimli')
class Guerreiro(Jogo):
  def __init__(self, nome, classe, vida, arma):
    super().__init__(nome, classe, vida, arma)

  def acao(self):
    print(f'O {self.classe} {self.nome} preparou seu escudo.')


    
  
  
  

  
from Veiculos import Veiculos
from Imprimivel import imprimir

class Moto(Veiculos, imprimir):
  def __init__(self,tipo, velocidade, modelo, cor):
    super().__init__(tipo, velocidade)
    self._modelo = modelo
    self._cor = cor
  

  @property
  def modelo(self):
      return self._modelo
  

  @modelo.setter
  def modelo(self,modelo):
    self._modelo = modelo

  @property 
  def cor(self):
    return self._cor

    
  @cor.setter
  def cor(self,cor):
    self._cor = cor

  def descricao(self):
    print(f'A moto do modelo {self.modelo} e da cor {self.cor} e tem velocidade de {self._velocidade} km')

  def imprimir(self):
    print(f'A moto do modelo {self.modelo}, tem velocidade de {self._velocidade}km e é muito bonita.')
